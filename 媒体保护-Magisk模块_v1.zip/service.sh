#!/system/bin/sh

until [ `getprop sys.boot_completed` -eq 1 ]
do
	sleep 1
done

echo PowerManagerService.noSuspend > /sys/power/wake_lock

export SHELL=/system/bin/sh
export PATH=/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:`magisk --path`/.magisk/busybox:/data/adb/ksu/bin:/data/adb/ap/bin

${0%/*}/main.sh ${0%/*}